
%
%
%% Hyper Parameters =======================================================

%Reset
clear
clc

frame_size = 256;        %log 256
num_FilterBanks = 35;
num_coefficeints = 12; 
show = false;

samples_tested = 14;

%% Creating Codebooks =====================================================
%  (Training)       
[code_series, lim1,lim2] = train(...
    frame_size, num_FilterBanks, num_coefficeints, show);


%% Prediction =============================================================

% Training Files (100% correct)
% audiofile_1 = "s1.wav";
% audiofile_2 = "s2.wav";
% audiofile_3 = "s3.wav";
% audiofile_4 = "s4.wav";
% audiofile_5 = "s5.wav";
% audiofile_6 = "s6.wav";
% audiofile_7 = "s7.wav";
% audiofile_8 = "s8.wav";
% audiofile_9 = "s8.wav";

% Original Test Files
audiofile_1 = "s1_test.wav";
audiofile_2 = "s2_test.wav";
audiofile_3 = "s3_test.wav";
audiofile_4 = "s4_test.wav";
audiofile_5 = "s5_test.wav";
audiofile_6 = "s6_test.wav";
audiofile_7 = "s7_test.wav";
audiofile_8 = "s8_test.wav";

% Non-Matches
audiofile_9 =  "s9.wav";
audiofile_10 = "s10.wav";
audiofile_11 = "s11.wav";

% Extra Testing
audiofile_12 = "s12_test.wav";
audiofile_13 = "s13_test.wav";
audiofile_14 = "s14_test.wav";

% string of audio files to pass
str = [audiofile_1, audiofile_2, audiofile_3,...
    audiofile_4, audiofile_5, audiofile_6,...
    audiofile_7, audiofile_8, audiofile_9,...
    audiofile_10, audiofile_11, audiofile_12,...
    audiofile_13, audiofile_14];

% Printing Table
VarNames = {'Tested Speaker ID:', 'Matched Speaker ID:', 'Deviation:'};
fprintf(1, '  %s\t %s\t %s\t \n', VarNames{:})


%% PER TESTED SAMPLE
for i = 1:samples_tested
    
    % Iterates for every audio file tested
    audiofile_current = str(i);

    %% Collecting Speaker Codebook
    [MFCC_own, MFCC_MATLAB] = melfb_own(...
    audiofile_current, frame_size, num_FilterBanks, num_coefficeints, show);
    [clusters_test] = lbg(MFCC_own, MFCC_MATLAB, show);
    codebook_speaker = clusters_test;
    codebook_speaker = codebook_speaker(1:lim1,1:lim2);    

    
    %% Decision Threshold
    length_series = 14; %how to index into for loop
    min_deviation = 10;
    deviation_threshold = 0.3; %check if no match found

    % Calculating Speakers Codebook
    speaker_superdot = zeros(height(clusters_test),1);
     
    for j = 1:height(clusters_test) %every cluster
        speaker_superdot(j,1) = mean(codebook_speaker(j,:));
    end 
    
    %% Find Deviation Per Codebook
    for m = 1:length_series
        
        codebook_superdot = zeros(height(clusters_test),1);

        %finding CODEBOOK superdot per cluster
        for j = 1:height(clusters_test) %every cluster
            codebook_temp = code_series(:,:,m);
            codebook_superdot(j,1) = mean(codebook_temp(j,:));
        end 
          
        % Comparing (Deviation) Superdots --------------------------------------------
        
        % Need double absolutes to take abs(deviation)
        initial_deviation = abs(codebook_superdot - speaker_superdot);
        current_deviation = abs(mean(initial_deviation));
     
        % Checks if its more likely the current speaker i
        if current_deviation < min_deviation
            speaker = m;
            min_deviation = current_deviation;
        end 
        if min_deviation > deviation_threshold
            speaker = 0;
        end
    end
    
    % printing results
    fprintf(1, '\n\t%s             \t%d              \t%d\n\n', audiofile_current, speaker, min_deviation')  
end 

