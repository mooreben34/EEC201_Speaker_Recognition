%
%
%% Training ===============================================================

function [code_series, lim1,lim2] = train(...
    frame_size, num_FilterBanks, num_coefficeints, show)

%% Calculating Codebook per Training speaker. 

%% Original Files =========================================================
    
    %s1
    [MFCC_own, MFCC_MATLAB] = melfb_own(...
    "s1.wav", frame_size, num_FilterBanks, num_coefficeints, show);
    [clusters_s1] = lbg(MFCC_own, MFCC_MATLAB, show);
    
    %s2
    [MFCC_own, MFCC_MATLAB] = melfb_own(...
    "s2.wav", frame_size, num_FilterBanks, num_coefficeints, show);
    [clusters_s2] = lbg(MFCC_own, MFCC_MATLAB, show);

    %s3
    [MFCC_own, MFCC_MATLAB] = melfb_own(...
    "s3.wav", frame_size, num_FilterBanks, num_coefficeints, show);
    [clusters_s3] = lbg(MFCC_own, MFCC_MATLAB, show);
    
    %s4
    [MFCC_own, MFCC_MATLAB] = melfb_own(...
    "s4.wav", frame_size, num_FilterBanks, num_coefficeints, show);
    [clusters_s4] = lbg(MFCC_own, MFCC_MATLAB, show); 
    
    %s5
    [MFCC_own, MFCC_MATLAB] = melfb_own(...
    "s5.wav", frame_size, num_FilterBanks, num_coefficeints, show);
    [clusters_s5] = lbg(MFCC_own, MFCC_MATLAB, show);
    
    %s6
    [MFCC_own, MFCC_MATLAB] = melfb_own(...
    "s6.wav", frame_size, num_FilterBanks, num_coefficeints, show);
    [clusters_s6] = lbg(MFCC_own, MFCC_MATLAB, show);
    
    %s7
    [MFCC_own, MFCC_MATLAB] = melfb_own(...
    "s7.wav", frame_size, num_FilterBanks, num_coefficeints, show);
    [clusters_s7] = lbg(MFCC_own, MFCC_MATLAB, show);

    %s8
    [MFCC_own, MFCC_MATLAB] = melfb_own(...
    "s8.wav", frame_size, num_FilterBanks, num_coefficeints, show);
    [clusters_s8] = lbg(MFCC_own, MFCC_MATLAB, show);

%% Extra Testing ===========================================================
    
    % s12
    [MFCC_own, MFCC_MATLAB] = melfb_own(...
    "s12.wav", frame_size, num_FilterBanks, num_coefficeints, show);
    [clusters_s12] = lbg(MFCC_own, MFCC_MATLAB, show);

    %s13
    [MFCC_own, MFCC_MATLAB] = melfb_own(...
    "s13.wav", frame_size, num_FilterBanks, num_coefficeints, show);
    [clusters_s13] = lbg(MFCC_own, MFCC_MATLAB, show);
    
    %s14
    [MFCC_own, MFCC_MATLAB] = melfb_own(...
    "s14.wav", frame_size, num_FilterBanks, num_coefficeints, show);
    [clusters_s14] = lbg(MFCC_own, MFCC_MATLAB, show);
  
    %DimensionReduction (Truncating)
    lim1 = height(clusters_s1);
    lim2 = width(clusters_s1);
 
    %% Storing each codebook into code_series
    code_series(:,:,1) = clusters_s1(1:lim1,1:lim2);
    code_series(:,:,2) = clusters_s2(1:lim1,1:lim2);
    code_series(:,:,3) = clusters_s3(1:lim1,1:lim2);
    code_series(:,:,4) = clusters_s4(1:lim1,1:lim2);
    code_series(:,:,5) = clusters_s5(1:lim1,1:lim2);
    code_series(:,:,6) = clusters_s6(1:lim1,1:lim2);
    code_series(:,:,7) = clusters_s7(1:lim1,1:lim2);
    code_series(:,:,8) = clusters_s8(1:lim1,1:lim2);
    
    % Empty Codebooks
    code_series(:,:,9) =  10*clusters_s1(1:lim1,1:lim2);
    code_series(:,:,10) = 10*clusters_s1(1:lim1,1:lim2);
    code_series(:,:,11) = 10*clusters_s1(1:lim1,1:lim2);
    
    code_series(:,:,12) = clusters_s12(1:lim1,1:lim2);
    code_series(:,:,13) = clusters_s13(1:lim1,1:lim2);
    code_series(:,:,14) = clusters_s14(1:lim1,1:lim2);

end