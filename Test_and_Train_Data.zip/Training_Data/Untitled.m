  z = randn(100,100);
   t = 1:100;
   x = 1:100;
surf(T,F,10*log10(abs(P)));
axis tight;
view(0,90);